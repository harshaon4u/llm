<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

# Email Check NestJS Project

This is a NestJS application that listens for incoming emails from Gmail using IMAP protocol and displays them in the console.

## Project Structure

- Uses NestJS framework with TypeScript
- IMAP email listening functionality
- Gmail integration with app passwords
- Email polling and real-time listening
- Console-based email display

## Key Components

- EmailService: Handles IMAP connection and email fetching
- EmailController: Provides REST endpoints for manual email checking
- Uses node-cron for periodic email polling
- Configured for Gmail IMAP (imap.gmail.com:993)

## Development Guidelines

- Follow NestJS best practices and conventions
- Use proper TypeScript typing
- Implement proper error handling for IMAP connections
- Log important events and errors
- Keep email credentials secure (consider environment variables for production)
