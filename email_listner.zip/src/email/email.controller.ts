import { Controller, Get, Logger } from '@nestjs/common';
import { EmailService } from './email.service';

@Controller('email')
export class EmailController {
  private readonly logger = new Logger(EmailController.name);

  constructor(private readonly emailService: EmailService) {}

  @Get('check')
  checkEmails() {
    this.logger.log('Manual email check requested');
    this.emailService.checkEmails();
    return { message: 'Email fetching is disabled' };
  }

  @Get('status')
  getStatus() {
    return { 
      message: 'Email listener is disabled',
      timestamp: new Date().toISOString()
    };
  }
}
