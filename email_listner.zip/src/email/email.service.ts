import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as Imap from 'imap';
import { simpleParser } from 'mailparser';
import fetch from 'node-fetch';
import { v4 as uuidv4 } from 'uuid';
import * as nodemailer from 'nodemailer';

@Injectable()
export class EmailService implements OnModuleInit {
  private imap: Imap;
  private readonly logger = new Logger(EmailService.name);
  private transporter: nodemailer.Transporter;

  constructor(private configService: ConfigService) {
    // Initialize IMAP connection with Gmail configuration using environment variables
    this.imap = new Imap({
      user: this.configService.get('GMAIL_EMAIL') || '',
      password: this.configService.get('GMAIL_APP_PASSWORD') || '',
      host: 'imap.gmail.com',
      port: 993,
      tls: true,
      tlsOptions: {
        rejectUnauthorized: false,
        servername: 'imap.gmail.com'
      },
      authTimeout: 10000,
      connTimeout: 60000,
      keepalive: {
        interval: 10000,
        idleInterval: 300000,
        forceNoop: true
      },
    });

    // Initialize nodemailer transporter for sending emails
    this.transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: this.configService.get('GMAIL_EMAIL') || '',
        pass: this.configService.get('GMAIL_APP_PASSWORD') || '',
      },
    });
  }

  onModuleInit() {
    this.connectAndListen();
  }

  private connectAndListen() {
    this.imap.once('ready', () => {
      this.logger.log('IMAP connection ready. Opening INBOX...');
      this.imap.openBox('INBOX', false, (err, box) => {
        if (err) {
          this.logger.error('Failed to open INBOX', err);
          return;
        }
        this.logger.log('INBOX opened. Waiting for new emails...');
      });
    });

    this.imap.on('mail', (numNewMsgs) => {
      this.logger.log(`New mail event: ${numNewMsgs} new message(s). Fetching...`);
      this.fetchLatestEmail();
    });

    this.imap.on('error', (err) => {
      this.logger.error('IMAP error', err);
    });

    this.imap.on('end', () => {
      this.logger.warn('IMAP connection ended. Reconnecting in 5 seconds...');
      setTimeout(() => this.imap.connect(), 5000);
    });

    this.imap.connect();
  }

  private async sendReplyEmail(toEmail: string, subject: string, replyContent: string, originalMessageId?: string) {
    try {
      const mailOptions = {
        from: this.configService.get('GMAIL_EMAIL') || 'vihangamihiranga8131671@gmail.com',
        to: toEmail,
        subject: `Re: ${subject}`,
        text: replyContent,
        inReplyTo: originalMessageId,
        references: originalMessageId,
      };

      const info = await this.transporter.sendMail(mailOptions);
      this.logger.log(`Reply email sent successfully to ${toEmail}. Message ID: ${info.messageId}`);
      return info;
    } catch (error) {
      this.logger.error(`Failed to send reply email to ${toEmail}:`, error);
      throw error;
    }
  }

  private async processApiResponseAndReply(apiResponse: string, fromEmail: string, subject: string, originalMessageId?: string) {
    try {
      // Parse the API response to extract issue type and reply mail content
      const lines = apiResponse.split('\n');
      let issueType = '';
      let replyMail = '';
      let isReplyMailSection = false;
      
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        
        // Extract Issue Type
        if (line.startsWith('Issue Type:')) {
          issueType = line.replace('Issue Type:', '').trim();
          isReplyMailSection = false;
        }
        
        // Extract Reply Mail content (multi-line)
        if (line.startsWith('Reply Mail:')) {
          replyMail = line.replace('Reply Mail:', '').trim();
          isReplyMailSection = true;
        } else if (isReplyMailSection && line) {
          // Continue collecting reply mail content until we hit another field or empty line
          if (!line.startsWith('Issue Type:') && 
              !line.startsWith('Status Code:') && 
              !line.startsWith('Message:') && 
              !line.startsWith('Reason:')) {
            replyMail += '\n' + line;
          } else {
            isReplyMailSection = false;
          }
        }
      }
      
      // Clean up the reply mail content
      replyMail = replyMail.trim();
      
      this.logger.log(`Parsed Issue Type: ${issueType}`);
      this.logger.log(`Parsed Reply Mail: ${replyMail}`);
      
      // Only send reply email if Issue Type is "Non-actionable" and Reply Mail is not indicating no reply needed
      if (issueType.toLowerCase() === 'non-actionable' && 
          replyMail && 
          !replyMail.toLowerCase().includes('no need to reply')) {
        
        this.logger.log('Non-actionable issue detected. Sending reply email...');
        await this.sendReplyEmail(fromEmail, subject, replyMail, originalMessageId);
      } else {
        this.logger.log(`No reply needed. Issue Type: ${issueType}, Reply Mail: ${replyMail}`);
      }
    } catch (error) {
      this.logger.error('Error processing API response for reply:', error);
    }
  }

  private async handleEmailApiIntegration(parsed: any, fromEmail: string) {
    const sessionId = uuidv4();
    const userId = fromEmail;
    const messageText = `Message-ID: ${parsed.messageId}\nSubject: ${parsed.subject}\nBody: ${parsed.text}\n`;

    // 1. Create session
    try {
      const sessionResponse = await fetch(`http://localhost:8282/apps/main_agent/users/${encodeURIComponent(userId)}/sessions/${sessionId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ state: { key1: 'value1', key2: 42 } })
      });
      
      this.logger.log(`Session API response status: ${sessionResponse.status} ${sessionResponse.statusText}`);
      
      if (!sessionResponse.ok) {
        const errorText = await sessionResponse.text();
        this.logger.error(`Session creation failed with status ${sessionResponse.status}: ${errorText}`);
        return;
      }
      
      this.logger.log(`Session created for user ${userId}, session ${sessionId}`);
    } catch (err) {
      this.logger.error('Session create API error', err);
    }

    // 2. Send chat message
    try {
      const response = await fetch('http://localhost:8282/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          appName: 'main_agent',
          userId,
          sessionId,
          newMessage: {
            role: 'user',
            parts: [{ text: messageText }]
          }
        })
      });
      
      this.logger.log(`Response status: ${response.status} ${response.statusText}`);
      
      if (!response.ok) {
        const errorText = await response.text();
        this.logger.error(`API call failed with status ${response.status}: ${errorText}`);
        return;
      }
      
      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        const responseData = await response.json();
        this.logger.log(`Chat message sent for user ${userId}, session ${sessionId}`);
        // this.logger.log('API Response:', JSON.stringify(responseData, null, 2));
        // Print content > parts > text if present
        if (Array.isArray(responseData)) {
          let apiResponseText = '';
          responseData.forEach((item, idx) => {
            if (item && item.content && Array.isArray(item.content.parts)) {
              item.content.parts.forEach((part, pidx) => {
                if (typeof part.text === 'string') {
                  this.logger.log(part.text);
                  apiResponseText += part.text + '\n';
                }
              });
            }
          });
          
          // Parse API response and send reply email only for Non-actionable issues
          if (apiResponseText.trim()) {
            await this.processApiResponseAndReply(
              apiResponseText.trim(),
              fromEmail,
              parsed.subject || 'No Subject',
              parsed.messageId
            );
          }
        }
      } else {
        const responseText = await response.text();
        this.logger.log(`Chat message sent for user ${userId}, session ${sessionId}`);
        this.logger.log('API Response (non-JSON):', responseText);
        
        // Parse API response and send reply email only for Non-actionable issues (non-JSON)
        if (responseText.trim()) {
          await this.processApiResponseAndReply(
            responseText.trim(),
            fromEmail,
            parsed.subject || 'No Subject',
            parsed.messageId
          );
        }
      }
    } catch (err) {
      this.logger.error('Chat API error', err);
    }
  }

  private fetchLatestEmail() {
    this.imap.openBox('INBOX', false, (err, box) => {
      if (err) {
        this.logger.error('Failed to open INBOX for fetching', err);
        return;
      }
      const seq = box.messages.total;
      if (seq === 0) return;
      
      // Search for the latest unread emails
      this.imap.search(['UNSEEN'], (searchErr, results) => {
        if (searchErr) {
          this.logger.error('Search error', searchErr);
          return;
        }
        
        if (!results || results.length === 0) {
          this.logger.log('No unread emails found');
          return;
        }
        
        // Get the latest unread email UIDs
        const latestUIDs = results.slice(-5); // Get last 5 unread emails
        
        const fetch = this.imap.fetch(latestUIDs, {
          bodies: '',
          struct: true,
          markSeen: true // This will automatically mark as read
        });
        
        fetch.on('message', (msg, seqno) => {
          let buffer = '';
          let uid = null;
          
          msg.on('body', (stream) => {
            stream.on('data', (chunk) => {
              buffer += chunk.toString('utf8');
            });
          });
          
          msg.once('attributes', (attrs) => {
            uid = attrs.uid;
          });
          
          msg.once('end', async () => {
            try {
              const parsed = await simpleParser(buffer);
              this.logger.log('--- New Email Received ---');
              this.logger.log(`UID: ${uid}`);
              this.logger.log(`From: ${parsed.from?.text}`);
              let toField = '';
              if (parsed.to) {
                if (Array.isArray(parsed.to)) {
                  toField = parsed.to.map(addrObj => addrObj.text).join(', ');
                } else if ('value' in parsed.to && Array.isArray(parsed.to.value)) {
                  toField = parsed.to.value.map(addr => addr.address).join(', ');
                } else if ('text' in parsed.to) {
                  toField = parsed.to.text;
                }
              }
              this.logger.log(`To: ${toField}`);
              this.logger.log(`Subject: ${parsed.subject}`);
              this.logger.log(`Message-ID: ${parsed.messageId}`);
              this.logger.log(`Text Body: ${parsed.text}`);
              // this.logger.log(`HTML Body: ${parsed.html}`);
              this.logger.log(`Email marked as read automatically`);
              this.logger.log('--------------------------');
              
              const fromEmail = parsed.from?.value?.[0]?.address || 'unknown';
              if (fromEmail === 'vihangamihirangaz2@gmail.com') {
                await this.handleEmailApiIntegration(parsed, fromEmail);
              } else {
                this.logger.log(`Skipping API integration for email from: ${fromEmail}`);
              }
            
            } catch (parseErr) {
              this.logger.error('Error parsing email', parseErr);
            }
          });
        });
        
        fetch.once('error', (fetchErr) => {
          this.logger.error('Fetch error', fetchErr);
        });
      });
    });
  }

  async checkEmails() {
    // Manually fetch the latest email(s) and print details
    return new Promise<void>((resolve, reject) => {
      this.imap.openBox('INBOX', false, (err, box) => {
        if (err) {
          this.logger.error('Failed to open INBOX for manual check', err);
          reject(err);
          return;
        }
        
        // Search for all emails (both read and unread) and get the latest ones
        this.imap.search(['ALL'], (searchErr, results) => {
          if (searchErr) {
            this.logger.error('Search error during manual check', searchErr);
            reject(searchErr);
            return;
          }
          
          if (!results || results.length === 0) {
            this.logger.log('No emails found.');
            resolve();
            return;
          }
          
          // Get the latest 5 emails
          const latestUIDs = results.slice(-5);
          
          const fetch = this.imap.fetch(latestUIDs, {
            bodies: '',
            struct: true,
            markSeen: true // This will automatically mark as read
          });
          
          let processedCount = 0;
          
          fetch.on('message', (msg, seqno) => {
            let buffer = '';
            let uid = null;
            
            msg.on('body', (stream) => {
              stream.on('data', (chunk) => {
                buffer += chunk.toString('utf8');
              });
            });
            
            msg.once('attributes', (attrs) => {
              uid = attrs.uid;
            });
            
            msg.once('end', async () => {
              try {
                const parsed = await (await import('mailparser')).simpleParser(buffer);
                this.logger.log('--- Manual Email Check ---');
                this.logger.log(`UID: ${uid}`);
                this.logger.log(`From: ${parsed.from?.text}`);
                let toField = '';
                if (parsed.to) {
                  if (Array.isArray(parsed.to)) {
                    toField = parsed.to.map(addrObj => addrObj.text).join(', ');
                  } else if ('value' in parsed.to && Array.isArray(parsed.to.value)) {
                    toField = parsed.to.value.map(addr => addr.address).join(', ');
                  } else if ('text' in parsed.to) {
                    toField = parsed.to.text;
                  }
                }
                this.logger.log(`To: ${toField}`);
                this.logger.log(`Subject: ${parsed.subject}`);
                this.logger.log(`Message-ID: ${parsed.messageId}`);
                this.logger.log(`Text Body: ${parsed.text}`);
                this.logger.log(`HTML Body: ${parsed.html}`);
                this.logger.log(`Email marked as read automatically`);
                this.logger.log('--------------------------');
                
                const fromEmail = parsed.from?.value?.[0]?.address || 'unknown';
                if (fromEmail === 'vihangamihirangaz2@gmail.com') {
                  await this.handleEmailApiIntegration(parsed, fromEmail);
                } else {
                  this.logger.log(`Skipping API integration for email from: ${fromEmail}`);
                }
                
                processedCount++;
                if (processedCount === latestUIDs.length) {
                  resolve();
                }
              } catch (parseErr) {
                this.logger.error('Error parsing email', parseErr);
                processedCount++;
                if (processedCount === latestUIDs.length) {
                  resolve();
                }
              }
            });
          });
          
          fetch.once('error', (fetchErr) => {
            this.logger.error('Fetch error', fetchErr);
            reject(fetchErr);
          });
        });
      });
    });
  }
}
