import os
from google.adk.agents import LlmAgent
from dotenv import load_dotenv
from google.adk.models.lite_llm import LiteLlm

load_dotenv()

os.environ['GOOGLE_API_KEY'] = os.getenv('GOOGLE_API_KEY')

import subprocess
import json
import time
from datetime import datetime, timedelta

def run_splunk_search(time_str: str) -> str:
    """
        Get splunk search results for the given time string.
        The time string should be in the format: "Sun Jul 27 22:38:39 2025"
        
        Args:
            time_str (str): The time string to search in Splunk.
            Example: "Sun Jul 27 22:38:39 2025"
            
        Returns:
            str: The status code and message from the Splunk search results.
    
    """
    # print("================================================")
    # print(f"Running Splunk search for time: {time_str}")
    # print("================================================")
    # Step 1: Parse input time string
    dt = datetime.strptime(time_str, "%a %b %d %H:%M:%S %Y")
    
    # Step 2: Calculate earliest and latest times (+/- 1 second)
    earliest_dt = dt - timedelta(seconds=1)
    latest_dt = dt + timedelta(seconds=1)

    # Step 3: Convert to UNIX timestamps
    earliest_unix = int(earliest_dt.timestamp())
    latest_unix = int(latest_dt.timestamp())

    # Step 4: Compose the search query
    search_query = (
        f"search index=main sourcetype=spectrum_mobile_caas2 \"API_RESPONSE\" "
        f"earliest={earliest_unix} latest={latest_unix} | table _time, _raw"
    )

    # Step 5: Prepare curl command
    curl_command = [
        "curl", "--location", "--insecure",
        "https://127.0.0.1:8089/services/search/jobs?output_mode=json",
        "--header", "Authorization: Bearer eyJraWQiOiJzcGx1bmsuc2VjcmV0IiwiYWxnIjoiSFM1MTIiLCJ2ZXIiOiJ2MiIsInR0eXAiOiJzdGF0aWMifQ.eyJpc3MiOiJ2aWhhbmdhMjIzNjUgZnJvbSBMQVBUT1AtS003OVZTSkEiLCJzdWIiOiJ2aWhhbmdhMjIzNjUiLCJhdWQiOiJhcGkiLCJpZHAiOiJTcGx1bmsiLCJqdGkiOiIzMzVhNGM0ZTJlMTIzNGRkZDIwZDhmYmFmMWRlZTU4NzgwNjM3YjRlMjlhZDFhNWRiNzFkMGYyYzlkYjY4NTAzIiwiaWF0IjoxNzUzNDY3NDg5LCJleHAiOjE3NTYwNTk0ODksIm5iciI6MTc1MzQ2NzQ4OX0.VdyGQhbnuE8P4E18oTA4b30tIFYJkblM_B1PXthFqOe7gUS0U3s102lKbz60vxcAJS0PslIqt0m4F5GHkKDBtA",
        "--header", "Content-Type: application/x-www-form-urlencoded",
        "--data-urlencode", f"search={search_query}"
    ]

    # Step 6: Run curl command
    try:
        result = subprocess.run(curl_command, capture_output=True, text=True, check=True)
        # print("CURL Output:\n", result.stdout)
        # Parse sid from the first response
        response_json = json.loads(result.stdout)
        sid = response_json.get("sid")
        if sid:
            # Poll job status until done
            status_url = f"https://127.0.0.1:8089/services/search/jobs/{sid}?output_mode=json"
            curl_command_status = [
                "curl", "--location", "--insecure",
                status_url,
                "--header", "Authorization: Bearer eyJraWQiOiJzcGx1bmsuc2VjcmV0IiwiYWxnIjoiSFM1MTIiLCJ2ZXIiOiJ2MiIsInR0eXAiOiJzdGF0aWMifQ.eyJpc3MiOiJ2aWhhbmdhMjIzNjUgZnJvbSBMQVBUT1AtS003OVZTSkEiLCJzdWIiOiJ2aWhhbmdhMjIzNjUiLCJhdWQiOiJhcGkiLCJpZHAiOiJTcGx1bmsiLCJqdGkiOiIzMzVhNGM0ZTJlMTIzNGRkZDIwZDhmYmFmMWRlZTU4NzgwNjM3YjRlMjlhZDFhNWRiNzFkMGYyYzlkYjY4NTAzIiwiaWF0IjoxNzUzNDY3NDg5LCJleHAiOjE3NTYwNTk0ODksIm5iciI6MTc1MzQ2NzQ4OX0.VdyGQhbnuE8P4E18oTA4b30tIFYJkblM_B1PXthFqOe7gUS0U3s102lKbz60vxcAJS0PslIqt0m4F5GHkKDBtA"
            ]
            max_wait = 30  # seconds
            waited = 0
            while True:
                status_result = subprocess.run(curl_command_status, capture_output=True, text=True, check=True)
                status_json = json.loads(status_result.stdout)
                dispatch_state = status_json.get("entry", [{}])[0].get("content", {}).get("dispatchState")
                if dispatch_state == "DONE":
                    break
                time.sleep(0.5)
                waited += 0.5
                if waited >= max_wait:
                    return "Timeout waiting for job to complete."
            # Prepare second curl command to get results
            results_url = f"https://127.0.0.1:8089/services/search/jobs/{sid}/results?output_mode=json"
            curl_command_results = [
                "curl", "--location", "--insecure",
                results_url,
                "--header", "Authorization: Bearer eyJraWQiOiJzcGx1bmsuc2VjcmV0IiwiYWxnIjoiSFM1MTIiLCJ2ZXIiOiJ2MiIsInR0eXAiOiJzdGF0aWMifQ.eyJpc3MiOiJ2aWhhbmdhMjIzNjUgZnJvbSBMQVBUT1AtS003OVZTSkEiLCJzdWIiOiJ2aWhhbmdhMjIzNjUiLCJhdWQiOiJhcGkiLCJpZHAiOiJTcGx1bmsiLCJqdGkiOiIzMzVhNGM0ZTJlMTIzNGRkZDIwZDhmYmFmMWRlZTU4NzgwNjM3YjRlMjlhZDFhNWRiNzFkMGYyYzlkYjY4NTAzIiwiaWF0IjoxNzUzNDY3NDg5LCJleHAiOjE3NTYwNTk0ODksIm5iciI6MTc1MzQ2NzQ4OX0.VdyGQhbnuE8P4E18oTA4b30tIFYJkblM_B1PXthFqOe7gUS0U3s102lKbz60vxcAJS0PslIqt0m4F5GHkKDBtA"
            ]
            result2 = subprocess.run(curl_command_results, capture_output=True, text=True, check=True)
            # Parse the JSON output
            results_json = json.loads(result2.stdout)
            if results_json.get("results"):
                raw = results_json["results"][0].get("_raw", "")
                import re
                # Extract statusCodeValue
                status_match = re.search(r"statusCodeValue=(\d+)", raw)
                status_code = status_match.group(1) if status_match else "N/A"
                # Extract error message (robust JSON parsing)
                message = "N/A"
                error_match = re.search(r'error=(\[[^\]]*\])', raw)
                if error_match:
                    try:
                        error_list = json.loads(error_match.group(1))
                        if error_list and isinstance(error_list, list):
                            message = error_list[0].get("message", "N/A")
                    except Exception:
                        pass
                result_string = f"Status Code: {status_code}, Message: {message}"
                print("================================================")
                print(result_string)
                print("================================================")
                return result_string
            else:
                return "No results found."
        else:
            return "No sid found in response."
    except subprocess.CalledProcessError as e:
        return f"Error running curl: {e.stderr}"



root_agent = LlmAgent(
    name="MainAIAssistant",
    model=LiteLlm(model="openai/gpt-4.1"),
    tools=[run_splunk_search],
    instruction="""
        You are an software application monitoring and management assistant. 
        If any issue occurs in the system, you will be notified from the splunk email alerts.
        You have to read the email and understand the issue.
        You have to find the time of the issue from the email and execute `run_splunk_search` tool with the time as input.
            Eg: `run_splunk_search("Sun Jul 27 22:38:39 2025")`
        
        You have two type of issues to handle:
         1. Actionable issues: 
            In some issues, status code suited with the error message. Those are our application issues.
            Read status code and error message from the  `run_splunk_search` tool output.
            If that issue status code is 400 or 500, and error message related to the status code.
                Eg: 500 - "Some internal server error occurred", 503 - "Payment Service is unavailable", etc.
                
         2. Non-actionable issues: 
            In some issues, status code not suited with the error message. Those are not our application issues.
            Read status code and error message from the `run_splunk_search` tool output.
            If that issue status code is 400 or 500, and error message not related to the status code.
                Eg: 500 - "Credit card is expired", 504 - "Credit Limit is exceeded", etc.
                
                
        Example output:
        ```
             Issue Type: Actionable
             Status Code: 500
             Message: Some internal server error occurred
             Reason: This is an actionable issue because the status code 500 indicates a server error, and the message suggests an internal server issue.
             Reply Mail: <No need to reply, this is an actionable issue>
        ```
        
        ```
             Issue Type: Non-actionable
             Status Code: 503
             Message: Credit card is expired
             Reason: This is a non-actionable issue because the status code 503 indicates a service not available, but the message suggests a user-related issue (expired credit card) rather than a server error.
             Reply Mail: Hi All, \n This error is not effecting our application. This is a user related issue, because the credit card is expired. Please check with the user. \n Thanks.\n Regards,\n AI Agent
        ```

    """,
    description="""
        This agent monitors system issues and responds to Splunk email alerts.
    """,
)