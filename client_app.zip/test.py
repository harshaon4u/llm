import subprocess
import json
import time
from datetime import datetime, timedelta

def run_splunk_search(time_str):
    # Step 1: Parse input time string
    dt = datetime.strptime(time_str, "%a %b %d %H:%M:%S %Y")
    
    # Step 2: Calculate earliest and latest times (+/- 1 second)
    earliest_dt = dt - timedelta(seconds=1)
    latest_dt = dt + timedelta(seconds=1)

    # Step 3: Convert to UNIX timestamps
    earliest_unix = int(earliest_dt.timestamp())
    latest_unix = int(latest_dt.timestamp())

    # Step 4: Compose the search query
    search_query = (
        f"search index=main sourcetype=spectrum_mobile_caas2 \"API_RESPONSE\" "
        f"earliest={earliest_unix} latest={latest_unix} | table _time, _raw"
    )

    # Step 5: Prepare curl command
    curl_command = [
        "curl", "--location", "--insecure",
        "https://127.0.0.1:8089/services/search/jobs?output_mode=json",
        "--header", "Authorization: Bearer eyJraWQiOiJzcGx1bmsuc2VjcmV0IiwiYWxnIjoiSFM1MTIiLCJ2ZXIiOiJ2MiIsInR0eXAiOiJzdGF0aWMifQ.eyJpc3MiOiJ2aWhhbmdhMjIzNjUgZnJvbSBMQVBUT1AtS003OVZTSkEiLCJzdWIiOiJ2aWhhbmdhMjIzNjUiLCJhdWQiOiJhcGkiLCJpZHAiOiJTcGx1bmsiLCJqdGkiOiIzMzVhNGM0ZTJlMTIzNGRkZDIwZDhmYmFmMWRlZTU4NzgwNjM3YjRlMjlhZDFhNWRiNzFkMGYyYzlkYjY4NTAzIiwiaWF0IjoxNzUzNDY3NDg5LCJleHAiOjE3NTYwNTk0ODksIm5iciI6MTc1MzQ2NzQ4OX0.VdyGQhbnuE8P4E18oTA4b30tIFYJkblM_B1PXthFqOe7gUS0U3s102lKbz60vxcAJS0PslIqt0m4F5GHkKDBtA",
        "--header", "Content-Type: application/x-www-form-urlencoded",
        "--data-urlencode", f"search={search_query}"
    ]

    # Step 6: Run curl command
    try:
        result = subprocess.run(curl_command, capture_output=True, text=True, check=True)
        print("CURL Output:\n", result.stdout)
        # Parse sid from the first response
        response_json = json.loads(result.stdout)
        sid = response_json.get("sid")
        if sid:
            # Poll job status until done
            status_url = f"https://127.0.0.1:8089/services/search/jobs/{sid}?output_mode=json"
            curl_command_status = [
                "curl", "--location", "--insecure",
                status_url,
                "--header", "Authorization: Bearer eyJraWQiOiJzcGx1bmsuc2VjcmV0IiwiYWxnIjoiSFM1MTIiLCJ2ZXIiOiJ2MiIsInR0eXAiOiJzdGF0aWMifQ.eyJpc3MiOiJ2aWhhbmdhMjIzNjUgZnJvbSBMQVBUT1AtS003OVZTSkEiLCJzdWIiOiJ2aWhhbmdhMjIzNjUiLCJhdWQiOiJhcGkiLCJpZHAiOiJTcGx1bmsiLCJqdGkiOiIzMzVhNGM0ZTJlMTIzNGRkZDIwZDhmYmFmMWRlZTU4NzgwNjM3YjRlMjlhZDFhNWRiNzFkMGYyYzlkYjY4NTAzIiwiaWF0IjoxNzUzNDY3NDg5LCJleHAiOjE3NTYwNTk0ODksIm5iciI6MTc1MzQ2NzQ4OX0.VdyGQhbnuE8P4E18oTA4b30tIFYJkblM_B1PXthFqOe7gUS0U3s102lKbz60vxcAJS0PslIqt0m4F5GHkKDBtA"
            ]
            max_wait = 30  # seconds
            waited = 0
            while True:
                status_result = subprocess.run(curl_command_status, capture_output=True, text=True, check=True)
                status_json = json.loads(status_result.stdout)
                dispatch_state = status_json.get("entry", [{}])[0].get("content", {}).get("dispatchState")
                if dispatch_state == "DONE":
                    break
                time.sleep(0.5)
                waited += 0.5
                if waited >= max_wait:
                    print("Timeout waiting for job to complete.")
                    return
            # Prepare second curl command to get results
            results_url = f"https://127.0.0.1:8089/services/search/jobs/{sid}/results?output_mode=json"
            curl_command_results = [
                "curl", "--location", "--insecure",
                results_url,
                "--header", "Authorization: Bearer eyJraWQiOiJzcGx1bmsuc2VjcmV0IiwiYWxnIjoiSFM1MTIiLCJ2ZXIiOiJ2MiIsInR0eXAiOiJzdGF0aWMifQ.eyJpc3MiOiJ2aWhhbmdhMjIzNjUgZnJvbSBMQVBUT1AtS003OVZTSkEiLCJzdWIiOiJ2aWhhbmdhMjIzNjUiLCJhdWQiOiJhcGkiLCJpZHAiOiJTcGx1bmsiLCJqdGkiOiIzMzVhNGM0ZTJlMTIzNGRkZDIwZDhmYmFmMWRlZTU4NzgwNjM3YjRlMjlhZDFhNWRiNzFkMGYyYzlkYjY4NTAzIiwiaWF0IjoxNzUzNDY3NDg5LCJleHAiOjE3NTYwNTk0ODksIm5iciI6MTc1MzQ2NzQ4OX0.VdyGQhbnuE8P4E18oTA4b30tIFYJkblM_B1PXthFqOe7gUS0U3s102lKbz60vxcAJS0PslIqt0m4F5GHkKDBtA"
            ]
            result2 = subprocess.run(curl_command_results, capture_output=True, text=True, check=True)
            print("Search Results:\n", result2.stdout)
        else:
            print("No sid found in response.")
    except subprocess.CalledProcessError as e:
        print("Error running curl:\n", e.stderr)

# Example usage
run_splunk_search("Sun Jul 27 22:38:39 2025")
