import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


def send_email(to_email, subject, body):
    """
    Send an email using SMTP.
    Args:
        to_email (str): Recipient email address
        subject (str): Email subject
        body (str): Email body (plain text)
    """
    # Email configuration
    from_email = "vihangamihirangaz2@gmail.com"
    smtp_server = "smtp.gmail.com"
    smtp_port = 587
    username = "vihangamihirangaz2@gmail.com"
    password = "sbbo adfl moul iqca"
    
    msg = MIMEMultipart()
    msg['From'] = from_email if from_email else username
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    try:
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            if username and password:
                server.login(username, password)
            server.sendmail(msg['From'], to_email, msg.as_string())
        print(f"Email sent to {to_email}")
    except Exception as e:
        print(f"Failed to send email: {e}")


if __name__ == "__main__":
    # Example usage - now you only need to pass the required parameters
    send_email(
        to_email="vihangamihiranga8131671@gmail.com",
        subject="Test Email",
        body="This is a test email from Python."
    ) 