import requests

url = "https://127.0.0.1:8088/services/collector/event"
headers = {
    "Authorization": "Splunk 0af05635-9170-4b2a-9c2a-0cdde785653f"
}
data = {
    "event": {
        "test": "Vihanga"
    }
}
response = requests.post(url, json=data, headers=headers, verify=False)
print(response.status_code, response.text)

