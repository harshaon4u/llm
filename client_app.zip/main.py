import subprocess
import os
import shutil

# Step 1: Conda environment names to delete
conda_envs_to_delete = [
    "agentic-bot-langmem",
    ".venv",
    "agent-bot-test",
]

# Step 2: Environment folders to delete (venv, .venv, .conda)
env_folders_to_delete = [
]

# --- Function to remove conda environments ---
print("=== Removing Conda environments ===")
for env in conda_envs_to_delete:
    print(f"Removing conda environment: {env}")
    try:
        result = subprocess.run(
            ["conda", "remove", "-n", env, "--all", "-y"],
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            shell=True  # Needed on Windows if conda isn't in PATH
        )
        print(result.stdout)
        print(f"✅ Successfully removed: {env}\n")
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to remove: {env}")
        print(f"Error: {e.stderr}\n")

# --- Function to delete folders ---
print("\n=== Deleting Environment Folders ===")
for folder in env_folders_to_delete:
    if os.path.exists(folder):
        try:
            print(f"Deleting folder: {folder}")
            shutil.rmtree(folder)
            print(f"✅ Successfully deleted: {folder}\n")
        except Exception as e:
            print(f"❌ Failed to delete: {folder}")
            print(f"Error: {e}\n")
    else:
        print(f"⚠️ Folder not found, skipping: {folder}\n")
