import streamlit as st
import importlib

# Import MESSAGES and send_to_splunk from exception_splunk_app.py
def get_exception_module():
    return importlib.import_module('exception_splunk_app')

exception_module = get_exception_module()
MESSAGES = exception_module.MESSAGES
send_to_splunk = exception_module.send_to_splunk

st.title('Splunk Exception Trigger Dashboard')
st.write('Click any message to trigger the corresponding error/event.')

# Show the success message at the top with max width
if 'success_msg' in st.session_state and st.session_state['success_msg']:
    st.success(st.session_state['success_msg'])
    st.session_state['success_msg'] = ''  # Clear after showing

# Add custom CSS for equal width and height
st.markdown(
    """
    <style>
    .equal-button {
        width: 100% !important;
        height: 100px !important;
        margin-bottom: 16px;
        font-size: 16px;
        white-space: normal;
        word-break: break-word;
    }
    .stButton>button {
        width: 100% !important;
        height: 100px !important;
        font-size: 16px !important;
        white-space: normal !important;
        word-break: break-word !important;
    }
    </style>
    """,
    unsafe_allow_html=True
)

message_items = list(MESSAGES.items())

rows = (len(message_items) + 2) // 3
for row in range(rows):
    cols = st.columns(3)
    for col_idx in range(3):
        idx = row * 3 + col_idx
        if idx < len(message_items):
            num, msg = message_items[idx]
            with cols[col_idx]:
                if st.button(f"{num}: {msg['level']} - {msg['message']}", key=f"btn_{num}"):
                    send_to_splunk(msg)
                    st.session_state['last_clicked'] = num
                    st.session_state['success_msg'] = f"Triggered and sent to Splunk: {msg['level']} - {msg['message']} (Status: {msg['status_code']})"
                    st.rerun()

# Optionally, show details of the last clicked message
if 'last_clicked' in st.session_state:
    num = st.session_state['last_clicked']
    msg = MESSAGES[num]
    st.markdown('---')
    st.subheader(f"Details for Message {num}")
    st.json(msg) 