import sys
import logging
import datetime
import uuid
from splunk_handler import SplunkHandler

# Configure Splunk HEC
SPLUNK_HEC_HOST = '127.0.0.1'  # e.g., 'splunk.example.com'
SPLUNK_HEC_PORT = 8088
SPLUNK_HEC_TOKEN = '0af05635-9170-4b2a-9c2a-0cdde785653f'
# jwiy qdof xjjd lyuw
SPLUNK_INDEX = 'main'  # or your desired index

# Set up Splunk logging handler
splunk_handler = SplunkHandler(
    host=SPLUNK_HEC_HOST,
    port=SPLUNK_HEC_PORT,
    token=SPLUNK_HEC_TOKEN,
    index=SPLUNK_INDEX,
    verify=False,  # Set to False if using self-signed certs
    sourcetype='spectrum_mobile_caas2',
)
logger = logging.getLogger('splunk_logger')
logger.setLevel(logging.INFO)
logger.addHandler(splunk_handler)

# Message mapping with different types and status codes
MESSAGES = {
    1: {
        'level': 'INFO',
        'message': 'Data saved successfully',
        'status_code': 201,
        'status_code_text': 'CREATED',
        'thread_info': 'XNIO-1 task-3',
        'logger_info': 'mcl_logging_logger.RequestLoggingFilter',
        'log_type': 'API_RESPONSE',
        'client_id': '-',
        'dd_env': 'proda',
        'dd_service': 'mbo-enddevicetradein',
        'dd_span_id': '72160425443421124',
        'dd_trace_id': '70f887ad894398263d64',
        'dd_version': '4.0.0-CC-78-build.78',
        'global_tracking_id': None,
        'session_id': '-',
        'thread_context_id': None,
        'traffic_transaction_id': 'KUSVYTLLR2CQbqVL2an6Q2',
        'user_id': None,
        'x_trace_id': '175202173163191381926731546377334545571',
        'request_uri': '/api/wishlist()',
        'duration': '98',
        'response_body': '',
        'data': 'null',
        'warning': '',
        'error_json': None,
        'headers_json': None,
        'log_suffix': '',
    },
    2: {
        'level': 'ERROR',
        'message': 'Invalid input parameters',
        'status_code': 400,
        'status_code_text': 'BAD_REQUEST',
        'thread_info': 'XNIO-1 task-3',
        'logger_info': 'mcl_logging_logger.RequestLoggingFilter',
        'log_type': 'API_RESPONSE',
        'client_id': '-',
        'dd_env': 'proda',
        'dd_service': 'mbo-enddevicetradein',
        'dd_span_id': '72160425443421124',
        'dd_trace_id': '70f887ad894398263d64',
        'dd_version': '4.0.0-CC-78-build.78',
        'global_tracking_id': None,
        'session_id': '-',
        'thread_context_id': None,
        'traffic_transaction_id': 'KUSVYTLLR2CQbqVL2an6Q2',
        'user_id': None,
        'x_trace_id': '175202173163191381926731546377334545571',
        'request_uri': '/api/payment()',
        'duration': '45',
        'response_body': '',
        'data': 'null',
        'warning': '',
        'error_json': None,
        'headers_json': None,
        'log_suffix': '<<< ERROR executing with exception',
    },
    3: {
        'level': 'ERROR',
        'message': 'Internal server error',
        'status_code': 500,
        'status_code_text': 'INTERNAL_SERVER_ERROR',
        'thread_info': 'XNIO-1 task-3',
        'logger_info': 'mcl_logging_logger.RequestLoggingFilter',
        'log_type': 'API_RESPONSE',
        'client_id': '-',
        'dd_env': 'proda',
        'dd_service': 'mbo-enddevicetradein',
        'dd_span_id': '72160425443421124',
        'dd_trace_id': '70f887ad894398263d64',
        'dd_version': '4.0.0-CC-78-build.78',
        'global_tracking_id': None,
        'session_id': '-',
        'thread_context_id': None,
        'traffic_transaction_id': 'KUSVYTLLR2CQbqVL2an6Q2',
        'user_id': None,
        'x_trace_id': '175202173163191381926731546377334545571',
        'request_uri': '/api/cart()',
        'duration': '100',
        'response_body': '',
        'data': 'null',
        'warning': '',
        'error_json': None,
        'headers_json': None,
        'log_suffix': '<<< ERROR executing with exception',
    },
    4: {
        'level': 'ERROR',
        'message': 'Database connection failed',
        'status_code': 502,
        'status_code_text': 'BAD_GATEWAY',
        'thread_info': 'XNIO-1 task-3',
        'logger_info': 'mcl_logging_logger.RequestLoggingFilter',
        'log_type': 'API_RESPONSE',
        'client_id': '-',
        'dd_env': 'proda',
        'dd_service': 'mbo-enddevicetradein',
        'dd_span_id': '72160425443421124',
        'dd_trace_id': '70f887ad894398263d64',
        'dd_version': '4.0.0-CC-78-build.78',
        'global_tracking_id': None,
        'session_id': '-',
        'thread_context_id': None,
        'traffic_transaction_id': 'KUSVYTLLR2CQbqVL2an6Q2',
        'user_id': None,
        'x_trace_id': '175202173163191381926731546377334545571',
        'request_uri': '/api/payment()',
        'duration': '150',
        'response_body': '',
        'data': 'null',
        'warning': '',
        'error_json': None,
        'headers_json': None,
        'log_suffix': '<<< ERROR executing with exception',
    },
    5: {
        'level': 'ERROR',
        'message': 'Device with DPP line not allowed for trade-in until look payment.',
        'status_code': 500,
        'status_code_text': 'INTERNAL_SERVER_ERROR',
        'thread_info': 'XNIO-1 task-3',
        'logger_info': 'mcl_logging_logger.RequestLoggingFilter',
        'log_type': 'API_RESPONSE',
        'client_id': '-',
        'dd_env': 'proda',
        'dd_service': 'mbo-enddevicetradein',
        'dd_span_id': '72160425443421124',
        'dd_trace_id': '70f887ad894398263d64',
        'dd_version': '4.0.0-CC-78-build.78',
        'global_tracking_id': None,
        'session_id': '-',
        'thread_context_id': None,
        'traffic_transaction_id': 'KUSVYTLLR2CQbqVL2an6Q2',
        'user_id': None,
        'x_trace_id': '175202173163191381926731546377334545571',
        'request_uri': '/api/tradein()',
        'duration': '232',
        'response_body': '',
        'data': 'null',
        'warning': '',
        'error_json': None,
        'headers_json': None,
        'log_suffix': '<<< ERROR executing with exception',
    },
    6: {
        'level': 'ERROR',
        'message': 'Customer eligibility validation failed for device upgrade.',
        'status_code': 500,
        'status_code_text': 'INTERNAL_SERVER_ERROR',
        'thread_info': 'XNIO-1 task-3',
        'logger_info': 'mcl_logging_logger.RequestLoggingFilter',
        'log_type': 'API_RESPONSE',
        'client_id': '-',
        'dd_env': 'proda',
        'dd_service': 'mbo-enddevicetradein',
        'dd_span_id': '72160425443421124',
        'dd_trace_id': '70f887ad894398263d64',
        'dd_version': '4.0.0-CC-78-build.78',
        'global_tracking_id': None,
        'session_id': '-',
        'thread_context_id': None,
        'traffic_transaction_id': 'KUSVYTLLR2CQbqVL2an6Q2',
        'user_id': None,
        'x_trace_id': '175202173163191381926731546377334545571',
        'request_uri': '/api/upgrade()',
        'duration': '187',
        'response_body': '',
        'data': 'null',
        'warning': '',
        'error_json': None,
        'headers_json': None,
        'log_suffix': '<<< ERROR executing with exception',
    },
    7: {
        'level': 'ERROR',
        'message': 'Account validation rules violated - insufficient credit score.',
        'status_code': 500,
        'status_code_text': 'INTERNAL_SERVER_ERROR',
        'thread_info': 'XNIO-1 task-3',
        'logger_info': 'mcl_logging_logger.RequestLoggingFilter',
        'log_type': 'API_RESPONSE',
        'client_id': '-',
        'dd_env': 'proda',
        'dd_service': 'mbo-enddevicetradein',
        'dd_span_id': '72160425443421124',
        'dd_trace_id': '70f887ad894398263d64',
        'dd_version': '4.0.0-CC-78-build.78',
        'global_tracking_id': None,
        'session_id': '-',
        'thread_context_id': None,
        'traffic_transaction_id': 'KUSVYTLLR2CQbqVL2an6Q2',
        'user_id': None,
        'x_trace_id': '175202173163191381926731546377334545571',
        'request_uri': '/api/credit-check()',
        'duration': '210',
        'response_body': '',
        'data': 'null',
        'warning': '',
        'error_json': None,
        'headers_json': None,
        'log_suffix': '<<< ERROR executing with exception',
    },
}

def send_to_splunk(message_obj, user_id="default_user"):
    import json
    timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    # Fill dynamic fields if not set
    global_tracking_id = message_obj['global_tracking_id'] or str(uuid.uuid4())
    thread_context_id = message_obj['thread_context_id'] or str(uuid.uuid4())
    user_id = user_id if user_id != "default_user" else (message_obj['user_id'] or "default_user")
    error_json = message_obj['error_json'] or json.dumps([
        {"code": "SpectrumLineDPP", "message": message_obj['message']}
    ])
    headers_json = message_obj['headers_json'] or json.dumps({
        "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
        "Cache-Control": "no-cache, no-store, max-age=0, must-revalidate",
        "X-Content-Type-options": "nosniff",
        "Vary": "Origin",
        "Expires": "0",
        "Pragma": "no-cache",
        "X-XSS-Protection": "1; mode=block",
        "Content-Type": "application/json"
    })
    log_line = (
        f"{timestamp} {message_obj['level']} {message_obj['thread_info']} {message_obj['logger_info']} : {message_obj['log_type']}, "
        f"client-id={message_obj['client_id']}, dd.env={message_obj['dd_env']}, dd.service={message_obj['dd_service']}, "
        f"dd.span_id={message_obj['dd_span_id']}, dd.trace_id={message_obj['dd_trace_id']}, dd.version={message_obj['dd_version']}, "
        f"globalTrackingId={global_tracking_id}, session-id={message_obj['session_id']}, "
        f"threadContextId={thread_context_id}, "
        f"traffic_transaction_id={message_obj['traffic_transaction_id']}, user-id={user_id}, "
        f"x-trace-id={message_obj['x_trace_id']}, requestUri={message_obj['request_uri']}, duration={message_obj['duration']}, "
        f"response={message_obj['response_body']}, body={message_obj['data']}, warning={message_obj['warning']}, "
        f"error={error_json}, "
        f"headers={headers_json}, "
        f"statusCode={message_obj['status_code_text']}, statusCodeValue={message_obj['status_code']} "
        f"{(' ' + message_obj['log_suffix']) if message_obj.get('log_suffix') else ''}"
    )
    logger.error(log_line)

def main():
    if len(sys.argv) < 2:
        print('Usage: python exception_splunk_app.py <number 1-7> [user_id]')
        print('\nAvailable message types:')
        print('1: Success message (201 CREATED)')
        print('2: Client error (400 BAD_REQUEST)')
        print('3: Server error (500 INTERNAL_SERVER_ERROR)')
        print('4: Server error (502 BAD_GATEWAY)')
        print('5: Validation error with 500 status (500 INTERNAL_SERVER_ERROR)')
        print('6: Eligibility validation error (500 INTERNAL_SERVER_ERROR)')
        print('7: Credit validation error (500 INTERNAL_SERVER_ERROR)')
        sys.exit(1)
    try:
        num = int(sys.argv[1])
        user_id = sys.argv[2] if len(sys.argv) > 2 else "default_user"
        if num not in MESSAGES:
            print('Please enter a number between 1 and 7.')
            sys.exit(1)
        message_obj = MESSAGES[num]
        print(f'Generated: {message_obj["level"]} - {message_obj["message"]} (Status: {message_obj["status_code"]})')
        send_to_splunk(message_obj, user_id)
        print(f'Message sent to Splunk with {message_obj["level"]} level')
        print(f'User ID: {user_id}')
    except ValueError:
        print('Invalid input. Please enter a valid integer between 1 and 7.')
        sys.exit(1)

if __name__ == '__main__':
    main() 